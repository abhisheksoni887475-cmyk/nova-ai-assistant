import os
from typing import Literal
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from openai import OpenAI

app = FastAPI(title="Nova AI API", version="0.1.0")
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY")) if os.environ.get("OPENAI_API_KEY") else None

class Message(BaseModel):
    role: Literal["user", "assistant"]
    content: str

class ChatRequest(BaseModel):
    messages: list[Message]
    mode: str = "chat"

@app.get("/")
def index():
    return FileResponse("index.html")

@app.post("/api/chat")
def chat(body: ChatRequest):
    if not client:
        raise HTTPException(status_code=503, detail="Set OPENAI_API_KEY on the server.")
    if not body.messages:
        raise HTTPException(status_code=400, detail="At least one message is required.")
    # Keep the model and prompt policy on the server; never expose API keys in browser JS.
    mode_guidance = {
        "chat": "Be a helpful, clear general-purpose assistant.",
        "code": "Help with code. Explain assumptions and provide safe, maintainable examples.",
        "image": "Help develop image concepts and prompts. Do not claim an image was generated.",
        "search": "Help structure research. Be transparent that live web search is not configured in this starter.",
        "memory": "Explain memory and privacy controls. Do not claim persistent memory is implemented."
    }
    try:
        response = client.responses.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-5"),
            instructions=mode_guidance.get(body.mode, mode_guidance["chat"]) +
                " Do not claim to have used tools that are not connected. Do not request secrets.",
            input=[{"role": m.role, "content": m.content} for m in body.messages[-20:]],
        )
        return {"reply": response.output_text}
    except Exception as exc:
        # Avoid returning internal exception details to visitors.
        raise HTTPException(status_code=502, detail="The model request failed. Check server logs and model access.") from exc

app.mount("/assets", StaticFiles(directory="."), name="assets")
