---
name: ai-assistant-site
description: Use when building, testing, or deploying an AI assistant website using the OpenAI API without a no-code builder, or planning a related ChatGPT plugin/App integration.
---

# Nova AI Site Builder

Help users build a practical, secure AI assistant website without relying on Lovable or another no-code generator.

## Workflow
1. Confirm the target platforms, feature priorities, and whether the user wants a local prototype, a hosted website, a ChatGPT plugin, or an Apps SDK experience. If context already establishes these, proceed.
2. Separate the website from the ChatGPT integration. A website using the OpenAI API is not automatically a ChatGPT plugin.
3. Prefer a simple, accessible frontend and a server-side API layer. Keep API keys on the server, use environment variables, and never embed secrets in browser code or source control.
4. Provide a component map, request flow, runnable implementation steps, tests, and deployment checklist. Mark unimplemented features as planned rather than working.
5. For ChatGPT integration, use the current Plugin Creator package workflow for reusable instructions and connected app integrations, and assess Apps SDK/MCP when an interactive in-ChatGPT UI is required. Do not promise public listing until review/publishing requirements are met.
6. Ask for approval before connecting accounts or enabling actions that affect external systems.
7. Include privacy controls, opt-in memory, export/deletion, authentication, rate limiting, and monitoring in production planning.
8. Do not claim deployment, tests, or external integrations succeeded unless actually verified.

## Starter feature boundaries
The accompanying website starter provides a chat UI and a server-side OpenAI Responses API route. Code, image, search, and automation modes are UI scaffolding and require separate implementations. Persistent memory is not implemented by the demo toggle.
