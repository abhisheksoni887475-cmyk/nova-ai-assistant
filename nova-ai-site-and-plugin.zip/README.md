# Nova AI — website starter

A responsive futuristic-dark AI assistant website starter. Built without Lovable.

## Included
- Responsive HTML/CSS/JS frontend with chat layout, tool navigation, theme toggle, prompt starters, and a demo memory toggle.
- FastAPI backend that calls the OpenAI Responses API.
- Server-side API-key handling; the key is never put in browser code.
- Plugin Creator skill package in `skills/ai-assistant-site/`.

## Run locally
Use Python 3.11+.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Set environment variables in the terminal before starting the server:

```bash
# macOS/Linux
export OPENAI_API_KEY="your-key"
export OPENAI_MODEL="gpt-5"
# Windows PowerShell
# $env:OPENAI_API_KEY="your-key"
# $env:OPENAI_MODEL="gpt-5"
uvicorn backend.main:app --reload
```

Open http://127.0.0.1:8000. Never commit `.env` or expose the key in frontend JavaScript.

## Before production
This is a starter, not a deployed service. Add authentication, rate limits, abuse protection, logging with privacy controls, database-backed conversations, user-controlled memory with export/delete, error monitoring, CSP/security headers, accessibility testing, and a deployment platform. Add live web search, image generation, and app automation as separate server-side integrations; those features are visual entry points only in this starter. Review model availability and pricing for your account before deploying.

## ChatGPT integration
The website is separate from a ChatGPT plugin. The bundled skill package describes the workflow and can be imported through Plugin Creator; a public listing or customer availability requires the applicable review and publishing steps in ChatGPT. For a ChatGPT-hosted interactive app, evaluate the Apps SDK/MCP path instead of assuming the website itself becomes a plugin.
