const $ = (s) => document.querySelector(s);
const input = $("#promptInput"), conversation = $("#conversation"), welcome = $("#welcome");
let mode = "chat", history = [];
const modeTitles = {chat:"A clearer way to think.",code:"Build with clarity.",image:"Imagine what comes next.",search:"Explore with better questions.",memory:"Your preferences, your control."};
function setMode(next) {
  mode = next;
  document.querySelectorAll("[data-mode]").forEach(b => b.classList.toggle("active", b.dataset.mode === next));
  $("#pageTitle").textContent = modeTitles[next] || modeTitles.chat;
  input.placeholder = next === "code" ? "Describe the code you want to build…" : next === "search" ? "What would you like to research?" : next === "image" ? "Describe a visual idea…" : "Ask Nova anything…";
}
document.querySelectorAll("[data-mode]").forEach(b => b.addEventListener("click", () => setMode(b.dataset.mode)));
document.querySelectorAll("[data-prompt]").forEach(b => b.addEventListener("click", () => { input.value = b.dataset.prompt; input.focus(); send(); }));
$("#newChat").addEventListener("click", clearChat);
$("#clearConversation").addEventListener("click", clearChat);
$("#themeToggle").addEventListener("click", () => document.body.classList.toggle("light"));
function clearChat(){history=[];conversation.innerHTML="";welcome.hidden=false;}
function addMessage(role, text) {
  welcome.hidden = true;
  const row = document.createElement("div"); row.className = "message " + role;
  if(role === "assistant"){const icon=document.createElement("div");icon.className="mini-avatar";icon.textContent="✦";row.append(icon);}
  const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=text;row.append(bubble);conversation.append(row);row.scrollIntoView({behavior:"smooth",block:"nearest"});return bubble;
}
async function send(){
  const prompt=input.value.trim(); if(!prompt) return;
  input.value=""; $("#sendButton").disabled=true;
  addMessage("user",prompt); history.push({role:"user",content:prompt});
  const bubble=addMessage("assistant","Thinking…");
  try {
    const response=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:history,mode})});
    if(!response.ok) throw new Error(response.status===503?"Backend is not configured yet. Follow README setup steps.":"Request failed ("+response.status+").");
    const data=await response.json(); bubble.textContent=data.reply || "No response returned."; history.push({role:"assistant",content:bubble.textContent});
  } catch(err){bubble.textContent="Nova is in preview mode. "+err.message+"\n\nStart the backend and configure OPENAI_API_KEY to enable model responses.";}
  finally{$("#sendButton").disabled=false;input.focus();}
}
$("#sendButton").addEventListener("click",send);
input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}});
$("#memoryToggle").addEventListener("change",e=>{e.target.nextElementSibling.textContent=e.target.checked?"On · demo":"Off";});
